let Time = document.getElementById("time");
setInterval(() => {
    let d = new Date();
    Time.innerHTML = d.toLocaleTimeString();
}, 1000)
